package Modelo;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;

public class Proyecto implements Serializable {

    private String codigo;
    private String titulo;
    private LocalDate fechaInicio;
    private String unidadDuracion;   // "semanas", "meses" o "años"
    private byte duracionEstimada;
    private Cliente suCliente;
    private Empleado suGerente;
    private ArrayList<Empleado> suEquipo;
    private String estado;           // INICIADO, EN CURSO, CANCELADO, FINALIZADO, SUSPENDIDO, APLAZADO

    /** Constructor completo (con equipo). */
    public Proyecto(String codigo, String titulo, LocalDate fechaInicio, String unidadDuracion,
                    byte duracionEstimada, Cliente suCliente, Empleado suGerente,
                    ArrayList<Empleado> suEquipo) {
        this.codigo = codigo;
        this.titulo = titulo;
        this.fechaInicio = fechaInicio;
        this.unidadDuracion = unidadDuracion;
        this.duracionEstimada = duracionEstimada;
        this.suCliente = suCliente;
        this.suGerente = suGerente;
        this.suEquipo = suEquipo;
        this.estado = "INICIADO"; // estado por defecto
    }

    /** Constructor sin equipo: crea una lista vacía. */
    public Proyecto(String codigo, String titulo, LocalDate fechaInicio, String unidadDuracion,
                    byte duracionEstimada, Cliente suCliente, Empleado suGerente) {
        this(codigo, titulo, fechaInicio, unidadDuracion, duracionEstimada,
                suCliente, suGerente, new ArrayList<Empleado>());
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public LocalDate getFechaInicio() { return fechaInicio; }
    public void setFechaInicio(LocalDate fechaInicio) { this.fechaInicio = fechaInicio; }

    public String getUnidadDuracion() { return unidadDuracion; }
    public void setUnidadDuracion(String unidadDuracion) { this.unidadDuracion = unidadDuracion; }

    public byte getDuracionEstimada() { return duracionEstimada; }
    public void setDuracionEstimada(byte duracionEstimada) { this.duracionEstimada = duracionEstimada; }

    public Cliente getSuCliente() { return suCliente; }
    public void setSuCliente(Cliente suCliente) { this.suCliente = suCliente; }

    public Empleado getSuGerente() { return suGerente; }
    public void setSuGerente(Empleado suGerente) { this.suGerente = suGerente; }

    public ArrayList<Empleado> getSuEquipo() { return suEquipo; }
    public void setSuEquipo(ArrayList<Empleado> suEquipo) { this.suEquipo = suEquipo; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    /** Suma la duración estimada a la fecha de inicio según la unidad. */
    public LocalDate determinarFechaFinalizacion() {
        LocalDate fin = fechaInicio;
        if (unidadDuracion.equals("semanas")) {
            fin = fechaInicio.plusWeeks(duracionEstimada);
        } else if (unidadDuracion.equals("meses")) {
            fin = fechaInicio.plusMonths(duracionEstimada);
        } else if (unidadDuracion.equals("años")) {
            fin = fechaInicio.plusYears(duracionEstimada);
        }
        return fin;
    }

    public void agregarIntegrante(Empleado nuevoIntegrante) {
        suEquipo.add(nuevoIntegrante);
    }

    /** Elimina al integrante con ese número de identificación. Devuelve el empleado eliminado o null si no existe. */
    public Empleado eliminarIntegrante(String numeroIdentificacion) {
        Empleado eliminado = null;
        for (int i = 0; i < suEquipo.size(); i++) {
            if (suEquipo.get(i).getNumeroIdentificacion().equals(numeroIdentificacion)) {
                eliminado = suEquipo.remove(i);
                break;
            }
        }
        return eliminado;
    }

    @Override
    public String toString() {
        return "Código: " + codigo
                + "\nTítulo: " + titulo
                + "\nFecha de inicio: " + fechaInicio
                + "\nDuración estimada: " + duracionEstimada + " " + unidadDuracion
                + "\nFecha de finalización: " + determinarFechaFinalizacion()
                + "\nEstado: " + estado
                + "\n--- Cliente ---\n" + suCliente
                + "\n--- Gerente ---\n" + suGerente
                + "\nIntegrantes en el equipo: " + suEquipo.size() + "\n";
    }
}
