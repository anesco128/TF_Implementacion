package Modelo;

/** Cliente que es una empresa. Tiene un Contacto (composición). */
public final class Empresa extends Cliente {

    private Contacto suContacto;

    public Empresa(String numeroIdentificacion, String nombre, String nombreCiudad, Contacto suContacto) {
        super(numeroIdentificacion, nombre, nombreCiudad);
        this.suContacto = suContacto;
    }

    public Contacto getSuContacto() { return suContacto; }
    public void setSuContacto(Contacto suContacto) { this.suContacto = suContacto; }

    @Override
    public String toString() {
        return "Tipo: Empresa\n" + super.toString() + "\n" + suContacto;
    }
}
