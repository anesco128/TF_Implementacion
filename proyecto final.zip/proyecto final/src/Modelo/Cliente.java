package Modelo;

import java.io.Serializable;

/**
 * Clase abstracta: no se puede crear un "Cliente" directamente,
 * solo una Empresa o una PersonaNatural (que heredan de esta clase).
 * Implementa Serializable para poder guardarla en un archivo de objetos.
 */
public abstract class Cliente implements Serializable {

    protected String numeroIdentificacion;
    protected String nombre;
    protected String nombreCiudad;

    public Cliente(String numeroIdentificacion, String nombre, String nombreCiudad) {
        this.numeroIdentificacion = numeroIdentificacion;
        this.nombre = nombre;
        this.nombreCiudad = nombreCiudad;
    }

    public String getNumeroIdentificacion() { return numeroIdentificacion; }
    public void setNumeroIdentificacion(String numeroIdentificacion) { this.numeroIdentificacion = numeroIdentificacion; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getNombreCiudad() { return nombreCiudad; }
    public void setNombreCiudad(String nombreCiudad) { this.nombreCiudad = nombreCiudad; }

    @Override
    public String toString() {
        return "Identificación: " + numeroIdentificacion
                + "\nNombre: " + nombre
                + "\nCiudad: " + nombreCiudad;
    }
}
