package Modelo;

/** Cliente que es una persona. "final" = nadie puede heredar de esta clase. */
public final class PersonaNatural extends Cliente {

    private String numeroTelefono;
    private String correoElectronico;

    public PersonaNatural(String numeroIdentificacion, String nombre, String nombreCiudad,
                          String numeroTelefono, String correoElectronico) {
        super(numeroIdentificacion, nombre, nombreCiudad); // llama al constructor de Cliente
        this.numeroTelefono = numeroTelefono;
        this.correoElectronico = correoElectronico;
    }

    public String getNumeroTelefono() { return numeroTelefono; }
    public void setNumeroTelefono(String numeroTelefono) { this.numeroTelefono = numeroTelefono; }

    public String getCorreoElectronico() { return correoElectronico; }
    public void setCorreoElectronico(String correoElectronico) { this.correoElectronico = correoElectronico; }

    @Override
    public String toString() {
        return "Tipo: Persona Natural\n" + super.toString()
                + "\nTeléfono: " + numeroTelefono
                + "\nCorreo: " + correoElectronico;
    }
}
