package Vista;

import Modelo.*;
import java.awt.BorderLayout;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import javax.swing.*;

public class UsaProyecto extends JFrame {

    // Listas compartidas por toda la ventana (static)
    private static ArrayList<Proyecto> losProyectos = new ArrayList<Proyecto>();
    private static ArrayList<Cliente> losClientes = new ArrayList<Cliente>();

    private static final String SIN_PROYECTOS = "No hay proyectos registrados.";

    private static final String[] OPERACIONES = {
        "1. Registrar un proyecto",
        "2. Consultar todos los proyectos",
        "3. Consultar los proyectos en curso",
        "4. Consultar el primer proyecto registrado",
        "5. Consultar el último proyecto registrado",
        "6. Consultar el gerente de un proyecto",
        "7. Consultar el equipo de un proyecto",
        "8. Consultar los proyectos de un gerente",
        "9. Consultar los proyectos de un cliente",
        "10. Registrar un integrante a un proyecto",
        "11. Registrar el equipo a un proyecto",
        "12. Eliminar un integrante de un proyecto",
        "13. Generar archivo de objetos de todos los proyectos",
        "14. Generar archivo de objetos de todos los clientes",
        "15. Leer archivo de objetos de todos los proyectos",
        "16. Leer archivo de objetos de todos los clientes",
        "17. Actualizar el estado de un proyecto",
        "18. Consultar los proyectos por tipo de cliente",
        "19. Consultar un proyecto por código"
    };

    // Componentes de la ventana
    private JComboBox<String> cmbOperaciones;
    private JButton btnEjecutar;
    private JTextArea txtResultado;

    /** Se lanza cuando el usuario cancela un cuadro de diálogo. */
    private static class Cancelado extends RuntimeException { }

    public UsaProyecto() {
        initComponents();
    }

    // ------------------------------------------------------------------
    //  INTERFAZ GRÁFICA
    // ------------------------------------------------------------------
    private void initComponents() {
        setTitle("Gestión de Proyectos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(5, 5));

        cmbOperaciones = new JComboBox<String>(OPERACIONES);
        btnEjecutar = new JButton("Ejecutar");
        txtResultado = new JTextArea();
        txtResultado.setEditable(false);

        JPanel panelSuperior = new JPanel();
        panelSuperior.add(new JLabel("Operación:"));
        panelSuperior.add(cmbOperaciones);
        panelSuperior.add(btnEjecutar);

        add(panelSuperior, BorderLayout.NORTH);
        add(new JScrollPane(txtResultado), BorderLayout.CENTER);

        // Al hacer clic en el botón se llama a ejecutarOperacion()
        btnEjecutar.addActionListener(e -> ejecutarOperacion());
    }

    /** Lee la opción elegida en el combo y llama al método correspondiente. */
    private void ejecutarOperacion() {
        int opcion = cmbOperaciones.getSelectedIndex() + 1; // el índice empieza en 0
        String resultado = "";
        try {
            switch (opcion) {
                case 1:
                    losProyectos = registrarProyecto(losProyectos);
                    resultado = "Proyecto registrado correctamente.";
                    break;
                case 2:
                    resultado = consultarTodosProyectos(losProyectos);
                    break;
                case 3:
                    resultado = consultarProyectosEnCurso(losProyectos);
                    break;
                case 4:
                    resultado = consultarPrimerProyecto(losProyectos);
                    break;
                case 5:
                    resultado = consultarUltimoProyecto(losProyectos);
                    break;
                case 6:
                    resultado = consultarGerenteProyectoDadoCodigo(losProyectos, pedirTexto("Código del proyecto:"));
                    break;
                case 7:
                    resultado = consultarEquipoProyectoDadoCodigo(losProyectos, pedirTexto("Código del proyecto:"));
                    break;
                case 8:
                    resultado = consultarProyectosDadoNumIDEGerente(losProyectos, pedirTexto("Identificación del gerente:"));
                    break;
                case 9:
                    resultado = consultarProyectosDadoNumIDECliente(losProyectos, pedirTexto("Identificación del cliente:"));
                    break;
                case 10:
                    resultado = registrarIntegranteProyectoDadoCodigo(losProyectos, pedirTexto("Código del proyecto:"));
                    break;
                case 11:
                    resultado = registrarEquipoProyectoDadoCodigo(losProyectos, pedirTexto("Código del proyecto:"));
                    break;
                case 12:
                    resultado = eliminarIntegranteProyectoDadoCodigo(losProyectos, pedirTexto("Código del proyecto:"));
                    break;
                case 13:
                    generarArchivoDeObjetosProyectos(losProyectos);
                    break;
                case 14:
                    generarArchivoDeObjetosClientes(losProyectos);
                    break;
                case 15:
                    losProyectos = leerArchivoDeObjetosProyectos();
                    resultado = consultarTodosProyectos(losProyectos);
                    break;
                case 16:
                    losClientes = leerArchivoDeObjetosClientes();
                    resultado = "Clientes leídos del archivo: " + losClientes.size() + "\n\n";
                    for (Cliente c : losClientes) {
                        resultado += c + "\n\n";
                    }
                    break;
                case 17:
                    resultado = actualizarEstadoProyectoDadoCodigo(losProyectos, pedirTexto("Código del proyecto:"));
                    break;
                case 18:
                    String tipo = pedirOpcion("Tipo de cliente:", new String[]{"Empresa", "PersonaNatural"});
                    resultado = consultarProyectosDadoTipoCliente(losProyectos, tipo);
                    break;
                case 19:
                    resultado = consultarProyectoDadoCodigo(losProyectos, pedirTexto("Código del proyecto:"));
                    break;
            }
        } catch (Cancelado ex) {
            resultado = "Operación cancelada.";
        }
        txtResultado.setText(resultado);
    }

    // ------------------------------------------------------------------
    //  MÉTODOS DE AYUDA PARA PEDIR DATOS (usan JOptionPane)
    // ------------------------------------------------------------------

    /** Pide un texto no vacío. Si el usuario cancela, lanza Cancelado. */
    private String pedirTexto(String mensaje) {
        String texto = null;
        while (texto == null || texto.trim().isEmpty()) {
            texto = JOptionPane.showInputDialog(this, mensaje);
            if (texto == null) {
                throw new Cancelado();
            }
        }
        return texto.trim();
    }

    /** Pide un número entero. Repite hasta que se escriba un número válido. */
    private int pedirEntero(String mensaje) {
        int numero = 0;
        boolean valido = false;
        while (!valido) {
            try {
                numero = Integer.parseInt(pedirTexto(mensaje));
                valido = true;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(this, "Debe escribir un número entero.");
            }
        }
        return numero;
    }

    /** Pide una fecha con formato aaaa-mm-dd. */
    private LocalDate pedirFecha(String mensaje) {
        LocalDate fecha = null;
        while (fecha == null) {
            try {
                fecha = LocalDate.parse(pedirTexto(mensaje));
            } catch (DateTimeParseException e) {
                JOptionPane.showMessageDialog(this, "Formato inválido. Ejemplo: 2026-02-15");
            }
        }
        return fecha;
    }

    /** Muestra una lista desplegable y devuelve la opción elegida. */
    private String pedirOpcion(String mensaje, String[] opciones) {
        Object elegido = JOptionPane.showInputDialog(this, mensaje, "Seleccione",
                JOptionPane.QUESTION_MESSAGE, null, opciones, opciones[0]);
        if (elegido == null) {
            throw new Cancelado();
        }
        return elegido.toString();
    }

    private String pedirTitulo() {
        String titulo = pedirTexto("Título del proyecto (entre 20 y 100 caracteres):");
        while (titulo.length() < 20 || titulo.length() > 100) {
            JOptionPane.showMessageDialog(this, "El título debe tener entre 20 y 100 caracteres.");
            titulo = pedirTexto("Título del proyecto (entre 20 y 100 caracteres):");
        }
        return titulo;
    }

    /** Valida la duración según la unidad (reglas del enunciado). */
    private boolean duracionValida(String unidad, int duracion) {
        boolean valida = false;
        if (unidad.equals("semanas") || unidad.equals("años")) {
            valida = duracion >= 1 && duracion <= 3;
        } else if (unidad.equals("meses")) {
            valida = (duracion >= 1 && duracion <= 11)
                    || (duracion >= 13 && duracion <= 23)
                    || (duracion >= 25 && duracion <= 35);
        }
        return valida;
    }

    private byte pedirDuracion(String unidad) {
        int duracion = pedirEntero("Duración estimada (en " + unidad + "):");
        while (!duracionValida(unidad, duracion)) {
            JOptionPane.showMessageDialog(this, "Duración no válida para " + unidad + ".\n"
                    + "semanas: 1 a 3 | meses: 1-11, 13-23, 25-35 | años: 1 a 3");
            duracion = pedirEntero("Duración estimada (en " + unidad + "):");
        }
        return (byte) duracion;
    }

    private Empleado pedirEmpleado(String rol) {
        String id = pedirTexto(rol + " - Número de identificación:");
        String nombre = pedirTexto(rol + " - Nombre completo:");
        String titulo = pedirTexto(rol + " - Título profesional:");
        int anios = pedirEntero(rol + " - Años de experiencia:");
        while (anios < 0 || anios > 100) {
            JOptionPane.showMessageDialog(this, "Años de experiencia no válidos.");
            anios = pedirEntero(rol + " - Años de experiencia:");
        }
        return new Empleado(id, nombre, titulo, (byte) anios);
    }

    /** Pide los datos de un cliente. Si ya existe en algún proyecto, lo reutiliza. */
    private Cliente pedirCliente(ArrayList<Proyecto> datos) {
        String tipo = pedirOpcion("Tipo de cliente:", new String[]{"Empresa", "PersonaNatural"});
        String id = pedirTexto("Cliente - Número de identificación:");

        Cliente existente = buscarCliente(datos, id);
        if (existente != null) {
            JOptionPane.showMessageDialog(this, "El cliente ya estaba registrado. Se usará ese cliente.");
            return existente;
        }

        String nombre = pedirTexto("Cliente - Nombre:");
        String ciudad = pedirTexto("Cliente - Ciudad:");
        Cliente nuevo;
        if (tipo.equals("Empresa")) {
            String nomContacto = pedirTexto("Contacto - Nombre completo:");
            String cargo = pedirTexto("Contacto - Cargo:");
            String tel = pedirTexto("Contacto - Teléfono:");
            String correo = pedirTexto("Contacto - Correo electrónico:");
            nuevo = new Empresa(id, nombre, ciudad, new Contacto(nomContacto, cargo, tel, correo));
        } else {
            String tel = pedirTexto("Cliente - Teléfono:");
            String correo = pedirTexto("Cliente - Correo electrónico:");
            nuevo = new PersonaNatural(id, nombre, ciudad, tel, correo);
        }
        losClientes.add(nuevo);
        return nuevo;
    }

    // ------------------------------------------------------------------
    //  MÉTODOS DE BÚSQUEDA
    // ------------------------------------------------------------------
    private Proyecto buscarProyecto(ArrayList<Proyecto> datos, String codigo) {
        Proyecto encontrado = null;
        for (Proyecto p : datos) {
            if (p.getCodigo().equals(codigo)) {
                encontrado = p;
                break;
            }
        }
        return encontrado;
    }

    private Cliente buscarCliente(ArrayList<Proyecto> datos, String id) {
        Cliente encontrado = null;
        for (Proyecto p : datos) {
            if (p.getSuCliente().getNumeroIdentificacion().equals(id)) {
                encontrado = p.getSuCliente();
                break;
            }
        }
        return encontrado;
    }

    // ------------------------------------------------------------------
    //  REGISTRO
    // ------------------------------------------------------------------
    public ArrayList<Proyecto> registrarProyecto(ArrayList<Proyecto> datos) {
        String codigo = generarCodigoProyecto(datos);
        String titulo = pedirTitulo();
        LocalDate fechaInicio = pedirFecha("Fecha de inicio (aaaa-mm-dd):");
        String unidad = pedirOpcion("Unidad de duración:", new String[]{"semanas", "meses", "años"});
        byte duracion = pedirDuracion(unidad);
        Cliente cliente = pedirCliente(datos);
        Empleado gerente = pedirEmpleado("Gerente");

        // Se registra sin equipo; los integrantes se agregan después
        Proyecto nuevo = new Proyecto(codigo, titulo, fechaInicio, unidad, duracion, cliente, gerente);
        datos.add(nuevo);
        return datos;
    }

    /** Código = año actual + "-" + consecutivo de 3 dígitos (reinicia cada año). */
    public String generarCodigoProyecto(ArrayList<Proyecto> datos) {
        int anio = LocalDate.now().getYear();
        int mayor = 0;
        for (Proyecto p : datos) {
            if (p.getCodigo().startsWith(anio + "-")) {
                int consecutivo = Integer.parseInt(p.getCodigo().substring(5));
                if (consecutivo > mayor) {
                    mayor = consecutivo;
                }
            }
        }
        return anio + "-" + String.format("%03d", mayor + 1);
    }

    public String registrarIntegranteProyectoDadoCodigo(ArrayList<Proyecto> datos, String codigoProyecto) {
        if (datos.isEmpty()) {
            return SIN_PROYECTOS;
        }
        Proyecto p = buscarProyecto(datos, codigoProyecto);
        if (p == null) {
            return "No existe un proyecto con el código " + codigoProyecto;
        }
        Empleado nuevo = pedirEmpleado("Integrante");
        p.agregarIntegrante(nuevo);
        return "Integrante registrado en el proyecto " + codigoProyecto;
    }

    public String registrarEquipoProyectoDadoCodigo(ArrayList<Proyecto> datos, String codigoProyecto) {
        if (datos.isEmpty()) {
            return SIN_PROYECTOS;
        }
        Proyecto p = buscarProyecto(datos, codigoProyecto);
        if (p == null) {
            return "No existe un proyecto con el código " + codigoProyecto;
        }
        int cantidad = pedirEntero("¿Cuántos integrantes desea registrar?");
        ArrayList<Empleado> equipo = new ArrayList<Empleado>();
        for (int i = 1; i <= cantidad; i++) {
            equipo.add(pedirEmpleado("Integrante " + i));
        }
        p.setSuEquipo(equipo);
        return "Equipo registrado en el proyecto " + codigoProyecto + " (" + cantidad + " integrantes)";
    }

    public String eliminarIntegranteProyectoDadoCodigo(ArrayList<Proyecto> datos, String codigoProyecto) {
        if (datos.isEmpty()) {
            return SIN_PROYECTOS;
        }
        Proyecto p = buscarProyecto(datos, codigoProyecto);
        if (p == null) {
            return "No existe un proyecto con el código " + codigoProyecto;
        }
        String id = pedirTexto("Identificación del integrante a eliminar:");
        Empleado eliminado = p.eliminarIntegrante(id);
        if (eliminado == null) {
            return "El integrante no pertenece al equipo del proyecto.";
        }
        return "Se eliminó al integrante: " + eliminado.getNombreCompleto();
    }

    public String actualizarEstadoProyectoDadoCodigo(ArrayList<Proyecto> datos, String codigoProyecto) {
        if (datos.isEmpty()) {
            return SIN_PROYECTOS;
        }
        Proyecto p = buscarProyecto(datos, codigoProyecto);
        if (p == null) {
            return "No existe un proyecto con el código " + codigoProyecto;
        }
        String estado = pedirOpcion("Nuevo estado:", new String[]{"INICIADO", "EN CURSO",
            "CANCELADO", "FINALIZADO", "SUSPENDIDO", "APLAZADO"});
        p.setEstado(estado);
        return "Estado actualizado a " + estado;
    }

    // ------------------------------------------------------------------
    //  CONSULTAS
    // ------------------------------------------------------------------
    public String consultarTodosProyectos(ArrayList<Proyecto> datos) {
        if (datos.isEmpty()) {
            return SIN_PROYECTOS;
        }
        String resultado = "";
        for (Proyecto p : datos) {
            resultado += p + "\n";
        }
        return resultado;
    }

    public String consultarProyectosEnCurso(ArrayList<Proyecto> datos) {
        if (datos.isEmpty()) {
            return SIN_PROYECTOS;
        }
        String resultado = "";
        for (Proyecto p : datos) {
            if (p.getEstado().equals("EN CURSO")) {
                resultado += p + "\n";
            }
        }
        if (resultado.isEmpty()) {
            resultado = "No hay proyectos en curso.";
        }
        return resultado;
    }

    public String consultarPrimerProyecto(ArrayList<Proyecto> datos) {
        if (datos.isEmpty()) {
            return SIN_PROYECTOS;
        }
        return datos.get(0).toString();
    }

    public String consultarUltimoProyecto(ArrayList<Proyecto> datos) {
        if (datos.isEmpty()) {
            return SIN_PROYECTOS;
        }
        return datos.get(datos.size() - 1).toString();
    }

    public String consultarProyectoDadoCodigo(ArrayList<Proyecto> datos, String codigoProyecto) {
        if (datos.isEmpty()) {
            return SIN_PROYECTOS;
        }
        Proyecto p = buscarProyecto(datos, codigoProyecto);
        if (p == null) {
            return "No existe un proyecto con el código " + codigoProyecto;
        }
        return p.toString();
    }

    public String consultarGerenteProyectoDadoCodigo(ArrayList<Proyecto> datos, String codigoProyecto) {
        if (datos.isEmpty()) {
            return SIN_PROYECTOS;
        }
        Proyecto p = buscarProyecto(datos, codigoProyecto);
        if (p == null) {
            return "No existe un proyecto con el código " + codigoProyecto;
        }
        return "GERENTE DEL PROYECTO " + codigoProyecto + "\n" + p.getSuGerente();
    }

    public String consultarEquipoProyectoDadoCodigo(ArrayList<Proyecto> datos, String codigoProyecto) {
        if (datos.isEmpty()) {
            return SIN_PROYECTOS;
        }
        Proyecto p = buscarProyecto(datos, codigoProyecto);
        if (p == null) {
            return "No existe un proyecto con el código " + codigoProyecto;
        }
        if (p.getSuEquipo().isEmpty()) {
            return "El proyecto " + codigoProyecto + " aún no tiene equipo.";
        }
        String resultado = "EQUIPO DEL PROYECTO " + codigoProyecto + "\n";
        for (Empleado e : p.getSuEquipo()) {
            resultado += e + "\n";
        }
        return resultado;
    }

    public String consultarProyectosDadoNumIDEGerente(ArrayList<Proyecto> datos, String numIDEGerente) {
        if (datos.isEmpty()) {
            return SIN_PROYECTOS;
        }
        String resultado = "";
        for (Proyecto p : datos) {
            if (p.getSuGerente().getNumeroIdentificacion().equals(numIDEGerente)) {
                resultado += p + "\n";
            }
        }
        if (resultado.isEmpty()) {
            resultado = "No hay proyectos con ese gerente.";
        }
        return resultado;
    }

    public String consultarProyectosDadoNumIDECliente(ArrayList<Proyecto> datos, String numIDECliente) {
        if (datos.isEmpty()) {
            return SIN_PROYECTOS;
        }
        String resultado = "";
        for (Proyecto p : datos) {
            if (p.getSuCliente().getNumeroIdentificacion().equals(numIDECliente)) {
                resultado += p + "\n";
            }
        }
        if (resultado.isEmpty()) {
            resultado = "No hay proyectos con ese cliente.";
        }
        return resultado;
    }

    public String consultarProyectosDadoTipoCliente(ArrayList<Proyecto> datos, String tipoCliente) {
        if (datos.isEmpty()) {
            return SIN_PROYECTOS;
        }
        String resultado = "";
        for (Proyecto p : datos) {
            // getSimpleName() devuelve "Empresa" o "PersonaNatural"
            if (p.getSuCliente().getClass().getSimpleName().equals(tipoCliente)) {
                resultado += p + "\n";
            }
        }
        if (resultado.isEmpty()) {
            resultado = "No hay proyectos con clientes de tipo " + tipoCliente;
        }
        return resultado;
    }

    // ------------------------------------------------------------------
    //  ARCHIVOS DE OBJETOS
    // ------------------------------------------------------------------
    public void generarArchivoDeObjetosProyectos(ArrayList<Proyecto> datos) {
        if (datos.isEmpty()) {
            JOptionPane.showMessageDialog(this, SIN_PROYECTOS);
            return;
        }
        // try-with-resources: el archivo se cierra solo al terminar el bloque
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream("datosProyectos"))) {
            for (Proyecto p : datos) {
                salida.writeObject(p);
            }
            JOptionPane.showMessageDialog(this, "Archivo datosProyectos generado con " + datos.size() + " proyectos.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al escribir el archivo: " + e.getMessage());
        }
    }

    public ArrayList<Proyecto> leerArchivoDeObjetosProyectos() {
        ArrayList<Proyecto> datos = new ArrayList<Proyecto>();
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream("datosProyectos"))) {
            while (true) {
                datos.add((Proyecto) entrada.readObject());
            }
        } catch (EOFException e) {
            // Se llegó al final del archivo: es la forma normal de terminar la lectura
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(this, "El archivo datosProyectos no existe todavía.");
        } catch (IOException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(this, "Error al leer el archivo: " + e.getMessage());
        }
        return datos;
    }

    public void generarArchivoDeObjetosClientes(ArrayList<Proyecto> datos) {
        if (datos.isEmpty()) {
            JOptionPane.showMessageDialog(this, SIN_PROYECTOS);
            return;
        }
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream("datosClientes"))) {
            for (Proyecto p : datos) {
                salida.writeObject(p.getSuCliente());
            }
            JOptionPane.showMessageDialog(this, "Archivo datosClientes generado.");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al escribir el archivo: " + e.getMessage());
        }
    }

    public ArrayList<Cliente> leerArchivoDeObjetosClientes() {
        ArrayList<Cliente> datos = new ArrayList<Cliente>();
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream("datosClientes"))) {
            while (true) {
                Cliente leido = (Cliente) entrada.readObject();
                // Verifica que el cliente no esté repetido
                boolean repetido = false;
                for (Cliente c : datos) {
                    if (c.getNumeroIdentificacion().equals(leido.getNumeroIdentificacion())) {
                        repetido = true;
                    }
                }
                if (!repetido) {
                    datos.add(leido);
                }
            }
        } catch (EOFException e) {
            // Fin del archivo
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(this, "El archivo datosClientes no existe todavía.");
        } catch (IOException | ClassNotFoundException e) {
            JOptionPane.showMessageDialog(this, "Error al leer el archivo: " + e.getMessage());
        }
        return datos;
    }

    // ------------------------------------------------------------------
    //  MAIN
    // ------------------------------------------------------------------
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new UsaProyecto().setVisible(true));
    }
}
